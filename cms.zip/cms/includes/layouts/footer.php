	<div id ="footer">Copyright 20xx, cms</div>
	 </body>
</html>
<?php
  // 5. Close database connection
  if(isset($connection)){
  mysqli_close($connection);}
?>