<!DOCTYPE html>
<html>
<head>
<title>CMS</title>
<link href="css/public.css" media="all" rel="stylesheet" type="text/css">
 </head>
	<body>
	<div id="header">
	<h1>CMS<h1>
	</div>