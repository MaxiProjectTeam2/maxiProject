<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in();?>
<?php
	   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }
  $patient_set = find_all_patients();
?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>
<div id="main">
  <div id="navigation">
    <br />
    <a href="admin.php">&laquo; Main menu</a><br />
  </div>
  <div id="page">
    <?php echo message(); ?>
    <h2>Manage patients</h2>
    <table>
      <tr>
        <th style="text-align: left; width: 200px;">Surname</th>
		<th style="text-align: left; width: 200px;">Forename</th>
        <th colspan="2" style="text-align: left;">Actions</th>
      </tr>
    <?php while($patient = mysqli_fetch_assoc($patient_set)) { ?>
      <tr>
        <td><?php echo htmlentities($patient["surname"]); ?>
		<td><?php echo htmlentities($patient["forename"]); ?>
		<br>
		</td>
        <td><a href="edit_patient.php?id=<?php echo urlencode($patient["patientID"]); ?>">Edit</a></td>
        <td><a href="delete_patient?id=<?php echo urlencode($patient["patientID"]); ?>" onclick="return confirm('Are you sure?');">Delete</a></td>
      </tr>
    <?php } ?>
    </table>
    <br />
    <a href="new_patient.php">Add new patient</a>
  </div>
</div>

<?php include("../includes/layouts/footer.php"); ?>