<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php confirm_logged_in()
	   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }
?>
<?php
$upload_ok=0;
if(isset($_POST['submit'])) {
	// process the form data
	$tmp_file = $_FILES['file_upload']['tmp_name'];
	$target_file = basename($_FILES['file_upload']['name']);
	
		$upload_dir = "profile_picture";
  
	// You will probably want to first use file_exists() to make sure
	// there isn't already a file by the same name.
	
	// move_uploaded_file will return false if $tmp_file is not a valid upload file 
	// or if it cannot be moved for any other reason
	if(move_uploaded_file($tmp_file, $upload_dir."/".$target_file)) {
		$message = "File uploaded successfully.";
		$upload_ok=1;
	} else {
		$error = $_FILES['file_upload']['error'];
		$message = $upload_errors[$error];
	}
	
}
if (isset($_POST['submit'])&&$upload_ok=1) {
  
  if (empty($errors)) {
    // Perform Create
	$path = $upload_dir."/".$target_file;
    $surname = mysql_prep($_POST["surname"]);
    $forename = mysql_prep($_POST["forename"]);
    
    $query  = "INSERT INTO patient (";
    $query .= "  forename, surname, photoFile";
    $query .= ") VALUES (";
    $query .= "  '{$forename}', '{$surname}','{$path}'";
    $query .= ")";
    $result = mysqli_query($connection, $query);

    if ($result) {
      // Success
      $_SESSION["message"] = "patient created.";
      redirect_to("manage_patient.php");
    } else {
      // Failure
      $_SESSION["message"] = "patient creation failed.";
    }
  }
} else {
  // This is probably a GET request
  
} // end: if (isset($_POST['submit']))

?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>
<div id="main">
  <div id="navigation">
    &nbsp;
  </div>
  <div id="page">
    <?php echo message(); ?>
    <?php echo form_errors($errors); ?>
    
    <h2>Create patient</h2>
    <form action="new_patient.php" enctype="multipart/form-data" method="post">
      <p>Surname:
        <input type="text" name="surname" value="" />
      </p>
      <p>Forename:
        <input type="text" name="forename" value="" />
      </p>
	  	<input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
		<input type="file" name="file_upload" />
		<br><br>
      <input type="submit" name="submit" value="Create" />
    </form>
    <br />
    <a href="manage_patient.php">Cancel</a>
  </div>
</div>

<?php include("../includes/layouts/footer.php"); ?>