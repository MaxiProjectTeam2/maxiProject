<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in()?>
<?php include("../includes/layouts/header.php"); ?>
<?php
	   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }
?>

<div id="main">
  <div id="navigation">
    <br />
    <a href="admin.php">&laquo; Main menu</a><br />
    <br><br><br>
    <a href="manage_video.php?type=video"  >Edit Video</a><br><br><br>
	<a href="manage_video.php?type=picture"  >Edit Image</a><br><br><br>
	<a href="manage_video.php?type=music" >Edit Music</a><br><br><br>
    <br />
</div>
<div id="page">
<?php echo message(); ?>
</div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
