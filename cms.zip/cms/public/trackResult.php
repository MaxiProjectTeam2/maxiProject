<?php require_once("../includes/session.php")?>
<?php require_once("../includes/functions.php") ?>
<?php confirm_logged_in();
	   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }?>
<?php 
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title>Track Result</title>
	</head>
	<body>
		<h1>Track Result</h1>
		<?php
			require_once("database.php");

			$sql = "SELECT * FROM viewHistory";
			$result = $db->query($sql);
			echo "<table>";
			echo "<tr>";
			echo "<th>Name</th>";
			echo "<th>Content Name</th>";
			echo "<th>Number of View</th>";
			echo "</tr>";
			while($row = $result -> fetch_assoc()){
				echo "<tr>";
				$patientId = $row["patientID"];
				$nameSql = "SELECT forename as name FROM patient where patientId = {$patientId}";
				$patientname = $db->query($nameSql);
				while($names = $patientname -> fetch_assoc()){
					$name = $names["name"];
					echo "<th>" . $name . "</th>";
				}
				$contentId = $row["contentID"];
				$contentSql = "SELECT caption FROM content  where contentID = {$contentId}";
				$contentName = $db->query($contentSql);
				while($contents = $contentName->fetch_assoc()){
					$cn = $contents["caption"];
					echo "<th>" . $cn . "</th>";
				}
				$viewId = $row["viewID"];
				echo "<th>" . $viewId . "</th>";
				echo "</tr>";
			}

			$db->close_connection();
		?>
	</body>
</html>
