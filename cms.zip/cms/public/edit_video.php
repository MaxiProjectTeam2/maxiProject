<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in();?>
<?php require_once("../includes/validation_functions.php"); ?>

<?php
	   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }
  $content = find_content_by_id($_GET["id"]);
  $type = $_GET["type"];
  if (!$content) {
    // admin ID was missing or invalid or 
    // admin couldn't be found in database
    redirect_to("manage_video.php");
  }

	if($_GET["type"]=="video"){
		$value = "video";
	}else if($_GET["type"]=="music"){
		$value = "music";
	}else if($_GET["type"]=="picture"){
		$value = "picture";
	}
?>

<?php
if (isset($_POST['submit'])) {
  // Process the form
  
  // validations
  $required_fields = array("caption", "topic","sub_topic");
  validate_presences($required_fields);
  
  $fields_with_max_lengths = array("caption" => 30,"topic" => 30,"sub_topic" => 30);
  validate_max_lengths($fields_with_max_lengths);
  
  if (empty($errors)) {
    
    // Perform Update

    $id = $_GET["id"];
    $caption = mysql_prep($_POST["caption"]);
	$topic = mysql_prep($_POST["topic"]);
	$sub_topic = mysql_prep($_POST["sub_topic"]);
  
    $query  = "UPDATE content SET ";
    $query .= "caption = '{$caption}', ";
	$query .= "topic = '{$topic}', ";
    $query .= "subtopic = '{$sub_topic}' ";
    $query .= "WHERE contentid = {$id} ";
    $query .= "LIMIT 1";
    $result = mysqli_query($connection, $query);

    if ($result && mysqli_affected_rows($connection) == 1) {
      // Success
      $_SESSION["message"] = "{$value} updated.";
      redirect_to("manage_video.php?type={$value}");
    } else {
      // Failure
      $_SESSION["message"] = "{$value} update failed.";
	  redirect_to("manage_video.php?type={$value}");
    }
  
  }
} else {
  // This is probably a GET request
  
} // end: if (isset($_POST['submit']))

?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>

<div id="main">
  <div id="navigation">
    &nbsp;
  </div>
  <div id="page">
    <?php echo message(); ?>
    <?php echo form_errors($errors); ?>
    
    <h2>Edit <?php echo $type;?>: <?php echo htmlentities($content["caption"]); ?> </h2>
    <form action="edit_video.php?type=<?php echo urlencode($_GET["type"]); ?>&id=<?php echo urlencode($_GET["id"]); ?>" method="post">
       <p>Caption:
				<input type="text" name="caption" value="" placeholder="<?php echo $content["caption"];?>" />
			  </p>
			  
			  <p>Topic: &nbsp;&nbsp;&nbsp;
				<input type="text" name="topic" value="" placeholder="<?php echo $content["topic"];?>"/>
			  </p>
			  
			  <p>SubTopic:
				<input type="text" name="sub_topic" value="" placeholder="<?php echo $content["subtopic"];?>"/>
			  </p>
			  <input type="hidden" name="type" value="<?php echo $value;?>">
			   <p>Language:&nbsp;&nbsp;&nbsp;&nbsp;
				<select name="language">
					<option value="English">English</option>
					<option value="Chinese">Chinese</option>
					<option value="French">French</option>
					<option value="other">Other</option>
				</select>
			  </p>
			  <input type="submit" name="submit" value="Edit" />
			 </form>
			 <br><br><br>
    <a href="manage_video.php?type=<?php echo $type;?>">Cancel</a>
  </div>
</div>

<?php include("../includes/layouts/footer.php"); ?>
