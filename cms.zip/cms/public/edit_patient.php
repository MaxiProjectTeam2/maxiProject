<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in();?>
<?php require_once("../includes/validation_functions.php"); ?>

<?php
		   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }
  $patient = find_patient_by_id($_GET["id"]);
  
  if (!$patient) {
    // admin ID was missing or invalid or 
    // admin couldn't be found in database
    redirect_to("manage_patient.php");
  }
?>

<?php
$upload_ok=0;
// In an application, this could be moved to a config file
$upload_errors = array(
	// http://www.php.net/manual/en/features.file-upload.errors.php
	UPLOAD_ERR_OK 				=> "No errors.",
	UPLOAD_ERR_INI_SIZE  	=> "Larger than upload_max_filesize.",
  UPLOAD_ERR_FORM_SIZE 	=> "Larger than form MAX_FILE_SIZE.",
  UPLOAD_ERR_PARTIAL 		=> "Partial upload.",
  UPLOAD_ERR_NO_FILE 		=> "No file.",
  UPLOAD_ERR_NO_TMP_DIR => "No temporary directory.",
  UPLOAD_ERR_CANT_WRITE => "Can't write to disk.",
  UPLOAD_ERR_EXTENSION 	=> "File upload stopped by extension."
);

if (isset($_POST['submit'])) {
  // Process the form
  // process the form data
	$tmp_file = $_FILES['file_upload']['tmp_name'];
	$target_file = basename($_FILES['file_upload']['name']);
	$upload_dir = "profile_picture";
  
	// You will probably want to first use file_exists() to make sure
	// there isn't already a file by the same name.
	
	// move_uploaded_file will return false if $tmp_file is not a valid upload file 
	// or if it cannot be moved for any other reason
	if(move_uploaded_file($tmp_file, $upload_dir."/".$target_file)) {
		$message = "File uploaded successfully.";
		$upload_ok=1;
	} else {
		$error = $_FILES['file_upload']['error'];
		$message = $upload_errors[$error];
	}
	
	if (isset($_POST['submit'])&&$upload_ok==1) {
		$path = $upload_dir."/".$target_file;
  // validations
  $required_fields = array("forename", "surname",);
  validate_presences($required_fields);
  
  $fields_with_max_lengths = array("forename" => 30,"surname"=>30);
  validate_max_lengths($fields_with_max_lengths);
  
  if (empty($errors)) {
    
    // Perform Update

    $patientid = $_GET["id"];
    $forename = mysql_prep($_POST["forename"]);
	$surname = mysql_prep($_POST["surname"]);
  
    $query  = "UPDATE patient SET ";
    $query .= "forename = '{$forename}', ";
    $query .= "surname = '{$surname}', ";
	$query .= "photofile = '{$path}' ";
    $query .= "WHERE patientid = {$patientid} ";
    $query .= "LIMIT 1";
    $result = mysqli_query($connection, $query);

    if ($result && mysqli_affected_rows($connection) == 1) {
      // Success
      $_SESSION["message"] = "patient updated.";
      redirect_to("manage_patient.php");
    } else {
      // Failure
      $_SESSION["message"] = "patient update failed.";
    }
  
  }
} else {
  // This is probably a GET request
  
} // end: if (isset($_POST['submit']))
}
?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>

<div id="main">
  <div id="navigation">
    &nbsp;
  </div>
  <div id="page">
    <?php echo message(); ?>
    <?php echo form_errors($errors); ?>
    <h2>Edit carer: <?php echo htmlentities($patient["forename"]); ?></h2>
	<img src="<?php echo find_picture_by_patientid($_GET["id"])["photofile"];?>" style="width:128px;height:128px;">
    <form action="edit_patient.php?id=<?php echo urlencode($_GET["id"]); ?>" enctype="multipart/form-data" method="POST">
      <p>forename:
        <input type="text" name="forename" value="<?php echo htmlentities($patient["forename"]); ?>" />
      </p>
      <p>Surname:
        <input type="text" name="surname" value="<?php echo htmlentities($patient["surname"]);?>" />
      </p>
	  <br>
	  	<input type="hidden" name="MAX_FILE_SIZE" value="209715200" />
		<input type="file" name="file_upload" />
		<br><br><br><br>
      <input type="submit" name="submit" value="Edit Admin" />
    </form>
    <br />
    <a href="manage_patient.php">Cancel</a>
  </div>
</div>

<?php include("../includes/layouts/footer.php"); ?>