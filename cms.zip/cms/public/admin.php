<?php require_once("../includes/session.php")?>
<?php require_once("../includes/functions.php") ?>
<?php confirm_logged_in();
	   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }?>
<?php $layout_context = "admin" ?>
<?php include("../includes/layouts/header.php") ?>
<div id=main>
  <div id=navigation>
    &nbsp
  </div>
  <div id=page>
    <h2>Admin Menu</h2>
    <p>Welcome to the admin area,<?php   
	echo htmlentities($_SESSION["username"]); ?>.</p>
	<ul>
		<li><a href=manage_content.php>Manage Content </a></li>
		<li><a href=manage_patient.php> Manage Patients</a></li>
		<li><a href=manage_admins.php>Manage carers</a></li>
		<li><a href=trackResult.php>Track result</a></li>
		<li><a href=logout.php>Logout</a></li>

	</ul>
  </div>
</div>

<?php include("../includes/layouts/footer.php") ?>
