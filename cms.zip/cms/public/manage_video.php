<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in();?>

<?php
	   if(!check_priority_by_username($_SESSION["username"])){
		  redirect_to("patientLogin.php");
	  }
	if($_GET["type"]=="video"){
		//$_SESSION["type"] = "video";
		$content_set = find_all_video($_GET["type"]);

	}else if($_GET["type"]=="music"){
		//$_SESSION["type"] = "music";
		$content_set = find_all_video($_GET["type"]);
		
	}else if($_GET["type"]=="picture"){
		//$_SESSION["type"] = "picture";
		$content_set = find_all_video($_GET["type"]);
		
	}
?>

<?php $layout_context = "admin"; ?>
<?php include("../includes/layouts/header.php"); ?>
<div id="main">
  <div id="navigation">
    <br />
    <a href="admin.php" >&laquo; Main menu</a><br />
  </div>
  <div id="page">
    <?php echo message(); ?>
    <h2>Manage <?php echo $_GET["type"]?></h2>
    <table>
      <tr>
        <th style="text-align: left; width: 200px;">Caption</th>
		<th style="text-align: left; width: 200px;">topic</th>
		<th style="text-align: left; width: 200px;">subtopic</th>
        <th colspan="2" style="text-align: left;">language</th>
      </tr>
    <?php while($content = mysqli_fetch_assoc($content_set)) { ?>
      <tr>
        <td><?php echo htmlentities($content["caption"]); ?>
		<td><?php echo htmlentities($content["topic"]); ?>
		<td><?php echo htmlentities($content["subtopic"]); ?>
		<td><?php echo htmlentities($content["language"]); ?>  &nbsp &nbsp 
		<?php 
		if($_GET["type"]=="picture"){
			$output ="<td>";
			$output.= "<img src=\"";
			$output.= htmlentities($content["path"]);
			$output.= " \" style=\"width:128px;height:128px;\">";
			echo $output;
		}
		?>
		<br>
		<?php //echo htmlentities($admin["hashed_password"]);?>
		</td>
        <td><a href="edit_video.php?type=<?php echo urlencode($_GET["type"]);?>&id=<?php echo urlencode($content["contentID"]); ?>">Edit</a></td>
        <td><a href="delete_video.php?type=<?php echo urlencode($_GET["type"]);?>&id=<?php echo urlencode($content["contentID"]); ?>" onclick="return confirm('Are you sure?');">Delete</a></td>
      </tr>
    <?php } ?>
    </table>
    <br />
    <a href="upload.php?type=<?php echo urlencode($_GET["type"]);?>">Add new <?php echo $_GET["type"]?> </a>
  </div>?
</div>

<?php include("../includes/layouts/footer.php"); ?>